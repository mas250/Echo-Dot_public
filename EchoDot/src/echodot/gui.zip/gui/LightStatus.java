
package echodot.gui;

/**
 *
 * @author 650016706
 */
public enum LightStatus {
    CYAN,
    BLUE,
    OFF
}
